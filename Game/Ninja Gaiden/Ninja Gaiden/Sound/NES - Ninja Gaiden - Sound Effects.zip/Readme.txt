Ninja Gaiden (NES)
Sound Effects ripped by Nai255

No credit needed, but feedback is welcome:
DoomedQuaker@hotmail.com